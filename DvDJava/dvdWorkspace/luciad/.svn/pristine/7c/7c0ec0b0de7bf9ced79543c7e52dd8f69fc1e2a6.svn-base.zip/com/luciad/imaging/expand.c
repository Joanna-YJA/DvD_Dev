kernel float4 expand(image2d_t in, int expandX, int expandY, int expandW, int expandH) {
  float2 inCoord = image_coord(in);
  return sample_nearest_f(in, inCoord);
}
