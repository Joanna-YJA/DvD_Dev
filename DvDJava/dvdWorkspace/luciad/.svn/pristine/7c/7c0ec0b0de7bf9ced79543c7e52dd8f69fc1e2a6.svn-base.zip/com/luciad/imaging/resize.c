kernel float4 resize(image2d_t in, float scaleX, float scaleY, int interpolationMode) {
  int INTERPOLATION_MODE_NONE = 0;
  int INTERPOLATION_MODE_LINEAR = 1;
  float2 inCoord = image_coord(in);

  if (interpolationMode == INTERPOLATION_MODE_NONE) {
    return sample_nearest_f(in, inCoord);
  }
  if (scaleX >= 1 || scaleY >= 1) {
    return sample_linear_f(in, inCoord);
  }

  float sx = 1 / (2 * scaleX);
  float sy = 1 / (2 * scaleY);
  uint count = 0;
  float4 total = 0;
  float2 srcCoord;
  for (float x = -sx; x < sx; x += 1) {
    for (float y = -sy; y < sy; y += 1) {
      srcCoord.x = inCoord.x + x;
      srcCoord.y = inCoord.y + y;
      total += sample_nearest_f(in, srcCoord);
      ++count;
    }
  }
  return total / count;
}
