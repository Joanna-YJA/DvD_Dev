kernel float4 composite(image2d_t in, image2d_t b ) {
  float2 bCoord = image_coord(b);
  float2 inCoord = image_coord(in);
  float4 result = float4(0.0f,0.0f,0.0f,0.0f);

  if(image_contains_f(b, bCoord)) {
    result = sample_nearest_f(b, bCoord);
  } else if(image_contains_f(in, inCoord)) {
    result = sample_nearest_f(in, inCoord);
  }

  return result;
}
