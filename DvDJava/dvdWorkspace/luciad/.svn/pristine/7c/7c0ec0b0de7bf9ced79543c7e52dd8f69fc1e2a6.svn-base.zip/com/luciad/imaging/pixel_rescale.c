kernel float4 pixel_rescale(image2d_t in, float4 scale, float4 offset) {
  return sample_f(in, image_coord(in)) * scale + offset;
}
