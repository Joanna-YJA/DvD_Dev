kernel float4 convolve(image2d_t in, float kernelWeights[], int kernelWidth, int kernelHeight) {
  float2 sampler_coord = image_coord(in);

  float4 outValue = 0.0f;
  int kernelSizeX = (kernelWidth - 1) / 2;
  int kernelSizeY = (kernelHeight - 1) / 2;
  for (int dy = -kernelSizeY; dy <= kernelSizeY; dy++) {
    int constantOffset = (kernelSizeY - dy) * kernelWidth + kernelSizeX;
    for (int dx = -kernelSizeX; dx <= kernelSizeX; dx++) {
      float2 sampleCoord = sampler_coord + float2(dx, dy);
      float weight = kernelWeights[constantOffset - dx];
      if (weight!=0 && image_contains_f(in, sampleCoord)) {
        float4 sampleValue = sample_nearest_f(in, sampleCoord);
        outValue += sampleValue * weight;
      }
    }
  }

  return outValue;
}
