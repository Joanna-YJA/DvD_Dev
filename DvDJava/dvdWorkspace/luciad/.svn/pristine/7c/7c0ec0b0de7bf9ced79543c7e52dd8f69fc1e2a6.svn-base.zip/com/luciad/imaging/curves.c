float clamp_channel_value(float channel_value, float control_points[], int point_count) {
  if (channel_value < control_points[0]) {
    return control_points[0];
  } else if(channel_value > control_points[(point_count*2)-2]) {
    return control_points[(point_count*2)-2];
  }
  return channel_value;
}

//TODO remove when clamping is correctly done in the OpenCL engine pipeline
float clamp_to_range(float value, float min, float max) {
  if (value<min) {
    return min;
  } else if(value>max) {
    return max;
  }
  return value;
}

int get_interval_index(float channel_value, float control_points[], int point_count) {
  if (channel_value < control_points[0] || channel_value > control_points[(point_count*2)-2]) {
    return -1;
  }

  for (int i=0; i<point_count*2; i+=2) {
    float first = control_points[i];
    float next = control_points[i+2];
    if(first <= channel_value){
      if(next >= channel_value){
        return i;
      }
    }
  }

  return -1;
}

float linear_interpolation(float channel_value, float control_points[], int point_count, float min, float max) {
  if (isnan(channel_value)) {
    return channel_value;
  }
  channel_value = clamp_channel_value(channel_value, control_points, point_count);
  int point_index = get_interval_index(channel_value, control_points, point_count);

  if (point_index < 0) {
    return 0.0f;
  }

  float x1 = control_points[point_index++];
  float y1 = control_points[point_index++];
  float x2 = control_points[point_index++];
  float y2 = control_points[point_index++];

  float m = (y2-y1)/(x2-x1);
  float b =y1-(m*x1);

  float result = (m*channel_value) + b;
  return clamp_to_range(result, min, max);
}

float square(float value) {
  return value*value;
}

float cube(float value) {
  return value*value*value;
}

float catmull_rom_nonuniform(float channel_value, float control_points[], int point_count, float min, float max) {
  if (isnan(channel_value)) {
    return channel_value;
  }
  channel_value = clamp_channel_value(channel_value, &control_points[2], point_count-2);
  int offset = get_interval_index(channel_value, &control_points[2], point_count-2);

  if (offset < 0) {
    return 0.0f;
  }

  float time_i = control_points[2+offset];
  float time_i_plus1 = control_points[4 + offset];
  float time_i_min1 = control_points[offset];
  float time_i_plus2 = control_points[6 + offset];

  float ti1_min_t = time_i_plus1 - channel_value;
  float t_min_ti = channel_value - time_i;

  float p1 = (float) (-(t_min_ti *square((channel_value- time_i_plus1)))/((time_i_plus1 - time_i_min1)*square(time_i - time_i_plus1)));

  float p2 = (float) ((square(channel_value- time_i_plus1)*(time_i - time_i_plus1 +2*(time_i -channel_value))/cube(time_i - time_i_plus1))
              - ((channel_value- time_i_plus1)*square(time_i -channel_value))/((time_i_plus2 - time_i)*square(time_i - time_i_plus1)));

  float p3 = (float)(((square(t_min_ti)*(time_i_plus1 - time_i + 2* ti1_min_t))/cube(time_i_plus1 - time_i))
      + (t_min_ti *square(ti1_min_t))/((time_i_plus1 - time_i_min1)*square(time_i_plus1 - time_i)));

  float p4 = (float)(((channel_value -time_i_plus1)*square(t_min_ti))/((time_i_plus2 - time_i)*square(time_i_plus1 - time_i)));

  float result = control_points[offset+1]*p1 + control_points[offset+3]*p2 + control_points[5+offset]*p3 + control_points[7+offset]*p4;
  return clamp_to_range(result, min, max);
}

kernel float4 curves(image2d_t in, float control_points[], int points_curve[], int curve_count, int interpolation, float min, float max) {
  float4 channel_value = sample_f(in, image_coord(in));
  float4 result;

  result.xyzw = 0.0f;

  if (interpolation == 0) {
    int offset1 = points_curve[0]*2;
    int offset2 = offset1 + (points_curve[1]*2);
    int offset3 = offset2 + (points_curve[2]*2);

    result.x = linear_interpolation(channel_value.x, control_points, points_curve[0], min, max);
    result.y = linear_interpolation(channel_value.y, &control_points[offset1], points_curve[1], min, max);
    result.z = linear_interpolation(channel_value.z, &control_points[offset2], points_curve[2], min, max);
    result.w = linear_interpolation(channel_value.w, &control_points[offset3], points_curve[3], min, max);
  } else if(interpolation == 1) {
    int offset1 = points_curve[0]*2;
    int offset2 = offset1 + (points_curve[1]*2);
    int offset3 = offset2 + (points_curve[2]*2);

    result.x = catmull_rom_nonuniform(channel_value.x, control_points, points_curve[0], min, max);
    result.y = catmull_rom_nonuniform(channel_value.y, &control_points[offset1], points_curve[1], min, max);
    result.z = catmull_rom_nonuniform(channel_value.z, &control_points[offset2], points_curve[2], min, max);
    result.w = catmull_rom_nonuniform(channel_value.w, &control_points[offset3], points_curve[3], min, max);
  }
  return result;
}

