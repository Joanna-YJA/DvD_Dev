float4 sample_3d_generic_f(image3d_t in, float3 coord, int interpolationMode) {
  int INTERPOLATION_MODE_NONE = 0;
  int INTERPOLATION_MODE_LINEAR = 1;

  if(interpolationMode == INTERPOLATION_MODE_NONE) {
    return sample3d_nearest_f(in, coord);
  } else if(interpolationMode == INTERPOLATION_MODE_LINEAR) {
    return sample3d_linear_f(in, coord);
  } else {
    return 0.0f;
  }
}

float4 sample_2d_generic_f(image2d_t in, float2 coord, int interpolationMode) {
  int INTERPOLATION_MODE_NONE = 0;
  int INTERPOLATION_MODE_LINEAR = 1;

  if(interpolationMode == INTERPOLATION_MODE_NONE) {
    return sample_nearest_f(in, coord);
  } else if(interpolationMode == INTERPOLATION_MODE_LINEAR) {
    return sample_linear_f(in, coord);
  } else {
    return 0.0f;
  }
}

float4 sample_1d_generic_f(image2d_t in, float coord, int interpolationMode) {
  int INTERPOLATION_MODE_NONE = 0;
  int INTERPOLATION_MODE_LINEAR = 1;

  float2 coord2 = float2(coord, 0.5f);
  if(interpolationMode == INTERPOLATION_MODE_NONE) {
    return sample_nearest_f(in, coord2);
  } else if(interpolationMode == INTERPOLATION_MODE_LINEAR) {
    return sample_linear_f(in, coord2);
  } else {
    return 0.0f;
  }
}

kernel float4 color_lookup(image2d_t in, image3d_t table, float3 tableOffset, float3 tableScale, int alphaMode, float4 nanColor, int interpolationMode) {
  int ALPHA_MODE_KEEP = 0;
  int ALPHA_MODE_REPLACE = 1;
  int ALPHA_MODE_MULTIPLY = 2;

  float4 inColor = sample_f(in, image_coord(in));
  if (isnan(inColor.x) || isnan(inColor.y) || isnan(inColor.z) || isnan(inColor.w)) {
   return nanColor;
  }

  float4 outColor = sample_3d_generic_f(table, tableOffset + inColor.xyz * tableScale, interpolationMode);
  if(alphaMode == ALPHA_MODE_KEEP) {
    outColor.w = inColor.w;
  } else if(alphaMode == ALPHA_MODE_REPLACE) {
    // no change needed
  } else if(alphaMode == ALPHA_MODE_MULTIPLY) {
    outColor.w *= inColor.w;
  }
  return outColor;
}

kernel float4 color_component_lookup(image2d_t in, image2d_t redTable, image2d_t greenTable, image2d_t blueTable, float3 tableOffset, float3 tableScale, float4 nanColor, int3 interpolationMode) {
  float4 inColor = sample_f(in, image_coord(in));
  if (isnan(inColor.x) || isnan(inColor.y) || isnan(inColor.z) || isnan(inColor.w)) {
   return nanColor;
  }

  float3 indexCoord = tableOffset + inColor.xyz * tableScale;
  return float4(
    sample_1d_generic_f(redTable, indexCoord.x, interpolationMode.x).x,
    sample_1d_generic_f(greenTable, indexCoord.y, interpolationMode.y).x,
    sample_1d_generic_f(blueTable, indexCoord.z, interpolationMode.z).x,
    inColor.w
  );
}

float4 sample_nearest_table(image2d_t table, int2 tableSize, float index) {
  float indexY = floor(index / tableSize.x);
  float indexX = index - indexY * tableSize.x;
  float2 coord = float2(indexX + 0.5f, indexY + 0.5f);
  return sample_nearest_f(table, coord);
}

kernel float4 index_lookup(image2d_t in, image2d_t table, int2 tableSize, float2 normalizeTo01ScaleOffset, float4 nanColor, int interpolationMode) {
  /**
   * The index is packed in a 2D texture because the texture size is typically limited in OpenCL. For example a 16-bit
   * index would require a width of ~65k.
   *
   * The total index size is tableSize.x * tableSize.y.
   */
  float inValue = sample_f(in, image_coord(in)).x;
  if (isnan(inValue)) {
   return nanColor;
  }

  float x = clamp(inValue * normalizeTo01ScaleOffset.x + normalizeTo01ScaleOffset.y, 0.0f, 1.0f);

  int INTERPOLATION_MODE_NONE = 0;
  int INTERPOLATION_MODE_LINEAR = 1;
  float size = tableSize.x * tableSize.y;
  if(interpolationMode == INTERPOLATION_MODE_NONE) {
    float ixf = clamp(x * size, 0.0f, size - 1.0f);
    float ix0 = floor(ixf);
    return sample_nearest_table(table, tableSize, ix0);
  } else {
    float ixf = clamp(x * (size - 1.0f), 0.0f, size - 1.0f);
    float ix0 = floor(ixf);
    float ix1 = clamp(ix0 + 1.0f, 0.0f, size - 1.0f);

    float wx1 = ixf - ix0;
    float wx0 = 1.0f - wx1;

    float4 c0 = sample_nearest_table(table, tableSize, ix0);
    float4 c1 = sample_nearest_table(table, tableSize, ix1);
    return c0 * wx0 + c1 * wx1;
  }
}
