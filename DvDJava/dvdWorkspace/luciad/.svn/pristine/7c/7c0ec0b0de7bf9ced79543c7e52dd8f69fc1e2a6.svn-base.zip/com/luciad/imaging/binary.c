kernel float4 binary(image2d_t image1, image2d_t image2, int mode) {
  const int ADD = 0;
  const int SUBTRACT = 1;
  const int MULTIPLY = 2;
  const int DIVIDE = 3;
  const int MIN = 4;
  const int MAX = 5;

  float4 p1 = sample_f(image1, image_coord(image1));
  float4 p2 = sample_f(image2, image_coord(image2));

  if (mode == ADD) {
    return p1 + p2;
  } else if (mode == SUBTRACT) {
    return p1 - p2;
  } else if (mode == MULTIPLY) {
    return p1 * p2;
  } else if (mode == DIVIDE) {
    return p1 / p2;
  } else if (mode == MIN) {
    return min(p1, p2);
  } else if (mode == MAX) {
    return max(p1, p2);
  }

  return p1;
}
