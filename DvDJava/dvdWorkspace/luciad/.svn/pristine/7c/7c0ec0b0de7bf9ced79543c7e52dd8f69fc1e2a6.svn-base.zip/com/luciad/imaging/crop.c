kernel float4 crop(image2d_t in, int x, int y, int width, int height) {
  float2 inCoord = image_coord(in);
  float4 result = float4(0.0f,0.0f,0.0f,0.0f);

  return sample_nearest_f(in, inCoord);
}
