// matrix is always 4x4 (row1, row2, row3, row4), column is always 4x1

kernel float4 pixel_transform(image2d_t in, float16 matrix, float4 column) {
  float4 pixel = sample_f(in, image_coord(in));

  float4 result;
  result.x = column.x + dot(matrix.s0123, pixel);
  result.y = column.y + dot(matrix.s4567, pixel);
  result.z = column.z + dot(matrix.s89AB, pixel);
  result.w = column.w + dot(matrix.sCDEF, pixel);

  return result;
}
