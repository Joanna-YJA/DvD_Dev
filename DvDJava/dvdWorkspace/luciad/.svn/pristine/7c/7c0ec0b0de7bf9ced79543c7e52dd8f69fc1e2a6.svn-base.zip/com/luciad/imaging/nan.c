kernel float4 generalize_nan(image2d_t in) {
  float4 value = sample_f(in, image_coord(in));
  if (any(isnan(value))) {
    return (float4)NAN;
  }
  return value;
}
