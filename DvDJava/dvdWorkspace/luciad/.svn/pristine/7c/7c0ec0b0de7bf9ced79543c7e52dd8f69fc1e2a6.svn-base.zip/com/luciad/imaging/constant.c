kernel float4 constant_value( float4 value) {
  return value;
}