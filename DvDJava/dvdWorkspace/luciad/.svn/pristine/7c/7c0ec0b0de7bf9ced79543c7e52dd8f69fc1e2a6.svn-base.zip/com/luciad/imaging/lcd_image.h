/**
 * Global constant for Not a Number
 */
const float NAN = 0.0f/0.0f;

/**
 * Global constants for true/false.
 */
const bool true = 0;
const bool false = 1;

/*
 * Declare printf function so we can use it in C functions for debugging purposes.
 */
//void printf();

/**
 * Returns the pixel coordinate in image that corresponds to the pixel currently being computed. The returned
 * value can be used directly when calling the sample family of methods.
 *
 * @param image the image for which to retrieve the pixel coordinate
 * @return an float2 containing the pixel coordinate in image that corresponds to dest_coord
 * @see dest_coord()
 */
float2 image_coord(image2d_t image);

/**
 * Returns the pixel coordinate of the pixel that is currently being computed.
 * @return an int2 containing the pixel coordinate of the pixel being computed
 * @see image_coord(image2d_t)
 */
int2 dest_coord();

/**
 * Determines if the given pixel coordinate is within the defined region of an image.
 * @param image the image
 * @param coord the pixel coordinate
 * @return true if the image is defined at the given coordinate; false otherwise
 */
bool image_contains_i(image2d_t image, int2 coord);

/**
 * Determines if the given pixel coordinate is within the defined region of an image.
 * @param image the image
 * @param coord the pixel coordinate
 * @return true if the image is defined at the given coordinate; false otherwise
 */
bool image_contains_f(image2d_t image, float2 coord);

/**
 * Alias for sample_nearest_i.
 * @see sample_nearest_i(image2d_t, int2)
 */
float4 sample_i(image2d_t, int2);

/**
 * Alias for sample_nearest_f.
 * @see sample_nearest_f(image2d_t, float2)
 */
float4 sample_f(image2d_t, float2);

/**
 * Samples a pixel from an image using linear interpolation.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 *
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample_linear_i(image2d_t image, int2 coord);

/**
 * Samples a pixel from an image using linear interpolation.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample_linear_f(image2d_t image, float2 coord);

/**
 * Samples a pixel from an image using nearest-neighbor sampling.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample_nearest_i(image2d_t image, int2 coord);

/**
 * Samples a pixel from an image using nearest-neighbor sampling.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample_nearest_f(image2d_t image, float2 coord);


/**
 * Math functions
 */

/**
* Round to integer toward negative infinity.
*/
float floor(float x);

/**
 * Round to integer toward positive infinity.
 */
float ceil(float x);

/**
* Compute x to the power of y (x^y)
**/
float pow(float x, float y);

/**
 * Computes the minimum of x and y.
 */
float4 min(float4 x, float4 y);

/**
 * Computes the maximum of x and y.
 */
float4 max(float4 x, float4 y);

/**
 * Clamps a value between minimum and maximum.
 */
float clamp(float aValue, float aMin, float aMax);

/**
* Checks for Nan Value
*/
float dot(float4 a, float4 b);

/**
* Checks for Nan Value
*/
int isnan(float value);

/**
 * Checks if any is true.
 */
int any(int x);

 /**
  * Returns the coordinates of the lower-left corner with respect to the lower-left corner of the whole
  * ALcdBasicImage.
  */
int2 global_corner_coord(image2d_t image);
