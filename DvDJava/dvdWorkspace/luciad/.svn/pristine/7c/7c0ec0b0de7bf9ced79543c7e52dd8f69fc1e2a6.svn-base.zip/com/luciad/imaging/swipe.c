kernel float4 swipe(image2d_t in, image2d_t b, int swipeX ) {
  int2 dest = dest_coord();
  float2 inCoord = image_coord(in);
  float2 bCoord = image_coord(b);
  float4 result = float4(0.0f,0.0f,0.0f,0.0f);

  int2 globalCoord = global_corner_coord(in);
  if(globalCoord.x+inCoord.x < swipeX) {
    result = sample_nearest_f(in, inCoord);
  } else {
    result = sample_nearest_f(b, bCoord);
  }
  return result;
}
