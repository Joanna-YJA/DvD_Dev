/**
 * Determines if the given pixel coordinate is within the defined region of an image.
 * @param image the image
 * @param coord the pixel coordinate
 * @return true if the image is defined at the given coordinate; false otherwise
 */
bool image3d_contains_i(image3d_t image, int3 coord);

/**
 * Determines if the given pixel coordinate is within the defined region of an image.
 * @param image the image
 * @param coord the pixel coordinate
 * @return true if the image is defined at the given coordinate; false otherwise
 */
bool image3d_contains_f(image3d_t image, float3 coord);

/**
 * Alias for sample_linear.
 * @see sample_linear(image3d_t, int3)
 */
float4 sample3d_i(image3d_t, int3);

/**
 * Alias for sample_linear.
 * @see sample_linear(image3d_t, float3)
 */
float4 sample3d_f(image3d_t, float3);

/**
 * Samples a pixel from an image using linear interpolation.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 *
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample3d_linear_i(image3d_t image, int3 coord);

/**
 * Samples a pixel from an image using linear interpolation.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample3d_linear_f(image3d_t image, float3 coord);

/**
 * Samples a pixel from an image using nearest-neighbor sampling.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample3d_nearest_i(image3d_t image, int3 coord);

/**
 * Samples a pixel from an image using nearest-neighbor sampling.
 * The returned float4 value will contain values normalized to the range [0.0-1.0]. If the image contains
 * less than 4 bands, the first values of the float4 will be populated with actual values. The remaining values will be
 * set to 0.0.
 * @param image the image
 * @param coord the pixel coordinate to sample
 * @return a float4 containing the sampled value
 */
float4 sample3d_nearest_f(image3d_t image, float3 coord);

