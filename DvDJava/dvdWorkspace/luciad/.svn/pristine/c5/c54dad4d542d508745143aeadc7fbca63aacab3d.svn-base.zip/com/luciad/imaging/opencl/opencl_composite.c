kernel float4 opencl_composite(image2d_t in) {
  float2 inCoord = image_coord(in);
  return sample_nearest_f(in, inCoord);
}
